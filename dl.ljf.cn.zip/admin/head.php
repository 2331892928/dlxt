<?php
//head

?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title><?=$config_sz['title']?></title>
<link rel="icon" href="../static/img/ico/favicon.ico" type="image/ico">
<meta name="keywords" content=<?=$config_sz['title1']?>>
<meta name="description" content=<?=$config_sz['title2']?>>
<meta name="author" content="yinqi">
<link href="../static/css/bootstrap.min.css" rel="stylesheet">
<link href="../static/css/materialdesignicons.min.css" rel="stylesheet">
<link href="../static/css/style.min.css" rel="stylesheet">
<link rel="stylesheet" href="../static/js/jquery.tagsinput.min.css">
<!--对话框-->
<link rel="stylesheet" href="../static/js/jquery-confirm.min.css">
</head>