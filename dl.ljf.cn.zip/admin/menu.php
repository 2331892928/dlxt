<?php


?>
			
			  
			  <!-- logo -->
			  <div id="logo" class="sidebar-header">
				  <!-- 采用光年后台，保留logo -->
			    <a href="index.php"><img src="../static/images/logo-sidebar.png" title="LightYear" alt="LightYear" /></a>
			  </div>
			  <div class="lyear-layout-sidebar-scroll"> 
			    
			    <nav class="sidebar-main">
			      <ul class="nav nav-drawer">
					<li class="nav-item active"> <a href="index.php"><i class="mdi mdi-home"></i> 后台首页</a> </li>
					<li class="nav-item nav-item-has-subnav">
					  <a href="javascript:void(0)"><i class="mdi mdi-palette"></i>网站设置</a>
					  <ul class="nav nav-subnav">
					    <li> <a href="set.php">设置</a> </li>
					  </ul>
					</li>
					<li class="nav-item nav-item-has-subnav">
					  <a href="javascript:void(0)"><i class="mdi mdi-format-align-justify"></i>短链管理</a>
					  <ul class="nav nav-subnav">
					    <li> <a href="dl_adm.php">短链列表</a> </li>
					  </ul>
					</li>
					</li>
			      </ul>
			    </nav>
			    
			    <div class="sidebar-footer">
			      <p class="copyright">Copyright &copy; 2050. <a target="_blank" href="http://www.ymypay.cn">湮灭网络</a> All rights reserved.</p>
				  <p class="copyright">项目论坛：<a target="_blank" href="http://bbs.ymypay.cn">湮灭短链论坛</a> 在此发布模板以及下载模板</p>
			    </div>
			  </div>