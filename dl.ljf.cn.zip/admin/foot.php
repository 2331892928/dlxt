<?php


?>
<script type="text/javascript" src="../static/js/jquery.min.js"></script>
<script type="text/javascript" src="../static/js/bootstrap.min.js"></script>
<script type="text/javascript" src="../static/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="../static/js/main.min.js"></script>

<!--图表插件-->
<script type="text/javascript" src="../static/js/Chart.js"></script>

<!-- 加载代码 -->
<script type="text/javascript" src="../static/js/jquery.lyear.loading.js"></script>
<script type="text/javascript" src="../static/js/bootstrap-notify.min.js"></script>
<!--标签插件-->
<script src="../static/js/jquery.tagsinput.min.js"></script>
<!-- 主题配色 -->
<script type="text/javascript" src="../static/js/jquery.cookie.js"></script>
<script type="text/javascript" src="../static/js/jquery.cookie.min.js"></script>
<!--对话框-->
<script src="../static/js/jquery-confirm.min.js"></script>