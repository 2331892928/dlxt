<?php

require 'config_db.php';
	$DB = new DB(DB_HOST,DB_USER,DB_PASSWD,DB_NAME,DB_PORT);
?>